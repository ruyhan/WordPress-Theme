<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
    'drone-13 (drones set)' => $set . '_f100',
  	'drone-12 (drones set)' => $set . '_f101',
  	'drone-11 (drones set)' => $set . '_f102',
  	'propeller-2 (drones set)' => $set . '_f103',
  	'propeller-1 (drones set)' => $set . '_f104',
  	'drone-10 (drones set)' => $set . '_f105',
  	'gamepad-1 (drones set)' => $set . '_f106',
  	'gamepad (drones set)' => $set . '_f107',
  	'augmented-reality (drones set)' => $set . '_f108',
  	'drone-9 (drones set)' => $set . '_f109',
  	'drone-8 (drones set)' => $set . '_f10a',
  	'drone-7 (drones set)' => $set . '_f10b',
  	'drone-6 (drones set)' => $set . '_f10c',
  	'photo-camera-1 (drones set)' => $set . '_f10d',
  	'engine (drones set)' => $set . '_f10e',
  	'drone-5 (drones set)' => $set . '_f10f',
  	'drone-4 (drones set)' => $set . '_f110',
  	'drone-3 (drones set)' => $set . '_f111',
  	'drone-2 (drones set)' => $set . '_f112',
  	'drone-1 (drones set)' => $set . '_f113',
  	'drone (drones set)' => $set . '_f114',
  	'photo-camera (drones set)' => $set . '_f115',
  	'screen (drones set)' => $set . '_f116',
  	'charger (drones set)' => $set . '_f117',
  	'signal (drones set)' => $set . '_f118',
  	'briefcase (drones set)' => $set . '_f119',
  	'location (drones set)' => $set . '_f11a',
  	'propeller (drones set)' => $set . '_f11b',
  	'radar-1 (drones set)' => $set . '_f11c',
  	'radar (drones set)' => $set . '_f11d'
);